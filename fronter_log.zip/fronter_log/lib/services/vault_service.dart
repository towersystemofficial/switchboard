import 'dart:io';
import 'package:csv/csv.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../models/member.dart';
import '../models/front_entry.dart';

/// Handles all reading/writing to the Obsidian vault.
///
/// Layout created inside the chosen vault folder:
///   <vault>/FronterLog/members/<id>.md   (YAML frontmatter + notes body)
///   <vault>/FronterLog/avatars/<id>.<ext>
///   <vault>/FronterLog/fronting_log.csv  (member_id,start,end,notes)
class VaultService {
  static const _prefsVaultKey = 'vault_path';
  static const _prefsPortKey = 'api_port';
  static const _prefsApiEnabledKey = 'api_enabled';
  static const _uuid = Uuid();

  String? _vaultPath;

  String? get vaultPath => _vaultPath;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _vaultPath = prefs.getString(_prefsVaultKey);
  }

  Future<void> setVaultPath(String path) async {
    _vaultPath = path;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsVaultKey, path);
    await _ensureStructure();
  }

  Future<int> getApiPort() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_prefsPortKey) ?? 8787;
  }

  Future<void> setApiPort(int port) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_prefsPortKey, port);
  }

  Future<bool> getApiEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_prefsApiEnabledKey) ?? false;
  }

  Future<void> setApiEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_prefsApiEnabledKey, enabled);
  }

  bool get isConfigured => _vaultPath != null && _vaultPath!.isNotEmpty;

  Directory get _rootDir => Directory(p.join(_vaultPath!, 'FronterLog'));
  Directory get _membersDir => Directory(p.join(_rootDir.path, 'members'));
  Directory get _avatarsDir => Directory(p.join(_rootDir.path, 'avatars'));
  File get _logFile => File(p.join(_rootDir.path, 'fronting_log.csv'));

  Future<void> _ensureStructure() async {
    if (!isConfigured) return;
    await _membersDir.create(recursive: true);
    await _avatarsDir.create(recursive: true);
    if (!await _logFile.exists()) {
      await _logFile.writeAsString('member_id,start,end,notes\n');
    }
  }

  String newId() => _uuid.v4();

  // ---------------- Members ----------------

  Future<List<Member>> loadMembers() async {
    if (!isConfigured) return [];
    await _ensureStructure();
    final files = _membersDir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.md'))
        .toList();
    final members = <Member>[];
    for (final f in files) {
      try {
        final content = await f.readAsString();
        members.add(_memberFromMarkdown(content, p.basenameWithoutExtension(f.path)));
      } catch (_) {
        // Skip unreadable/malformed files rather than crashing the app.
      }
    }
    members.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return members;
  }

  Future<void> saveMember(Member m) async {
    await _ensureStructure();
    final file = File(p.join(_membersDir.path, '${m.id}.md'));
    await file.writeAsString(_memberToMarkdown(m));
  }

  Future<void> deleteMember(Member m) async {
    final file = File(p.join(_membersDir.path, '${m.id}.md'));
    if (await file.exists()) await file.delete();
    if (m.avatarFilename != null) {
      final avatar = File(p.join(_avatarsDir.path, m.avatarFilename!));
      if (await avatar.exists()) await avatar.delete();
    }
  }

  /// Copies [source] into the vault's avatars folder and returns the stored filename.
  Future<String> saveAvatar(String memberId, File source) async {
    await _ensureStructure();
    final ext = p.extension(source.path).isNotEmpty ? p.extension(source.path) : '.jpg';
    final filename = '$memberId$ext';
    final dest = File(p.join(_avatarsDir.path, filename));
    await source.copy(dest.path);
    return filename;
  }

  String? avatarPath(String? filename) {
    if (filename == null || !isConfigured) return null;
    return p.join(_avatarsDir.path, filename);
  }

  String _memberToMarkdown(Member m) {
    final buffer = StringBuffer();
    buffer.writeln('---');
    buffer.writeln('id: ${m.id}');
    buffer.writeln('name: "${_escape(m.name)}"');
    buffer.writeln('pronouns: "${_escape(m.pronouns)}"');
    buffer.writeln('role: "${_escape(m.role)}"');
    buffer.writeln('color: "${m.colorHex}"');
    buffer.writeln('avatar: "${m.avatarFilename ?? ''}"');
    buffer.writeln('---');
    buffer.writeln();
    buffer.writeln(m.notes);
    return buffer.toString();
  }

  Member _memberFromMarkdown(String content, String fallbackId) {
    final parsed = _parseFrontmatter(content);
    final meta = parsed.$1;
    final body = parsed.$2;
    return Member(
      id: meta['id'] ?? fallbackId,
      name: meta['name'] ?? 'Unnamed',
      pronouns: meta['pronouns'] ?? '',
      role: meta['role'] ?? '',
      colorHex: (meta['color'] != null && meta['color']!.isNotEmpty) ? meta['color']! : '#7C83FD',
      avatarFilename: (meta['avatar'] != null && meta['avatar']!.isNotEmpty) ? meta['avatar'] : null,
      notes: body,
    );
  }

  String _escape(String s) => s.replaceAll('"', '\\"');

  /// Returns (metadata map, body text) from a markdown file with YAML frontmatter.
  (Map<String, String>, String) _parseFrontmatter(String content) {
    final lines = content.split('\n');
    if (lines.isEmpty || lines.first.trim() != '---') {
      return (<String, String>{}, content.trim());
    }
    final meta = <String, String>{};
    int i = 1;
    for (; i < lines.length; i++) {
      if (lines[i].trim() == '---') {
        i++;
        break;
      }
      final line = lines[i];
      final idx = line.indexOf(':');
      if (idx == -1) continue;
      final key = line.substring(0, idx).trim();
      var value = line.substring(idx + 1).trim();
      if (value.length >= 2 &&
          ((value.startsWith('"') && value.endsWith('"')) ||
              (value.startsWith("'") && value.endsWith("'")))) {
        value = value.substring(1, value.length - 1);
      }
      meta[key] = value.replaceAll('\\"', '"');
    }
    final body = (i <= lines.length) ? lines.sublist(i).join('\n').trim() : '';
    return (meta, body);
  }

  // ---------------- Fronting log ----------------

  Future<List<FrontEntry>> loadFrontingLog() async {
    if (!isConfigured) return [];
    await _ensureStructure();
    final content = await _logFile.readAsString();
    if (content.trim().isEmpty) return [];
    final rows = const CsvToListConverter(eol: '\n').convert(content);
    if (rows.isEmpty) return [];
    final dataRows = rows.first.isNotEmpty && rows.first.first.toString() == 'member_id'
        ? rows.skip(1)
        : rows;
    final entries = <FrontEntry>[];
    for (final row in dataRows) {
      if (row.isEmpty || row.first.toString().trim().isEmpty) continue;
      try {
        entries.add(FrontEntry.fromCsvRow(row));
      } catch (_) {
        // Skip malformed rows.
      }
    }
    entries.sort((a, b) => a.start.compareTo(b.start));
    return entries;
  }

  Future<void> writeFrontingLog(List<FrontEntry> entries) async {
    await _ensureStructure();
    final rows = <List<String>>[
      ['member_id', 'start', 'end', 'notes'],
      ...entries.map((e) => e.toCsvRow()),
    ];
    final csv = const ListToCsvConverter(eol: '\n').convert(rows);
    await _logFile.writeAsString('$csv\n');
  }
}
