import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';

import '../models/member.dart';

/// Shows a persistent ("ongoing") notification with the current fronter.
///
/// Note: this uses a plain ongoing notification (autoCancel: false, ongoing: true),
/// which Android will keep visible but is not a guaranteed foreground service.
/// If Android kills the app process outright, the notification can disappear.
/// Upgrading to a true foreground service (e.g. via flutter_foreground_task) is a
/// natural next step if you need stronger persistence guarantees.
class NotificationService {
  static const int _notificationId = 1001;
  static const String _channelId = 'current_fronter_channel';
  static const String _channelName = 'Current Fronter';
  static const String _channelDescription =
      'Persistent notification showing who is currently fronting.';

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(initSettings);

    final androidPlugin =
        _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.requestNotificationsPermission();
    await androidPlugin?.createNotificationChannel(
      const AndroidNotificationChannel(
        _channelId,
        _channelName,
        description: _channelDescription,
        importance: Importance.low,
        showBadge: false,
      ),
    );
    _initialized = true;
  }

  Future<void> showCurrentFronter(Member? member, DateTime? since) async {
    if (!_initialized) await init();
    if (member == null) {
      await clear();
      return;
    }
    final timeStr = since != null ? DateFormat('h:mm a').format(since) : '';
    final details = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.low,
      priority: Priority.low,
      ongoing: true,
      autoCancel: false,
      onlyAlertOnce: true,
      showWhen: false,
      icon: '@mipmap/ic_launcher',
    );
    await _plugin.show(
      _notificationId,
      'Fronting: ${member.name}',
      since != null ? 'Since $timeStr' : null,
      NotificationDetails(android: details),
    );
  }

  Future<void> clear() async {
    await _plugin.cancel(_notificationId);
  }
}
