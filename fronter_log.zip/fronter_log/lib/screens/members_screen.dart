import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/system_provider.dart';
import '../widgets/member_avatar.dart';
import 'member_edit_screen.dart';

class MembersScreen extends StatelessWidget {
  const MembersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SystemProvider>();

    if (!provider.isVaultConfigured) {
      return const Center(child: Text('Set up your vault folder in Settings first.'));
    }

    return Scaffold(
      body: provider.members.isEmpty
          ? const Center(child: Text('No members yet. Tap + to add one.'))
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.85,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemCount: provider.members.length,
              itemBuilder: (context, i) {
                final member = provider.members[i];
                return Card(
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => MemberEditScreen(member: member)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          MemberAvatar(
                            member: member,
                            radius: 36,
                            avatarFullPath: provider.avatarPath(member.avatarFilename),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            member.name,
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.ellipsis,
                          ),
                          if (member.role.isNotEmpty)
                            Text(
                              member.role,
                              style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                            ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: provider.isVaultConfigured
            ? () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const MemberEditScreen(member: null)),
                )
            : null,
        child: const Icon(Icons.add),
      ),
    );
  }
}
