import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../providers/system_provider.dart';
import '../widgets/fronter_card.dart';
import '../widgets/member_avatar.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  void _showSwitchSheet(BuildContext context, SystemProvider provider) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        if (provider.members.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(32),
            child: Text('Add a system member first, from the Members tab.'),
          );
        }
        return SafeArea(
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.symmetric(vertical: 12),
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Text('Who is fronting?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              ...provider.members.map((m) => ListTile(
                    leading: MemberAvatar(
                      member: m,
                      radius: 20,
                      avatarFullPath: provider.avatarPath(m.avatarFilename),
                    ),
                    title: Text(m.name),
                    subtitle: m.role.isNotEmpty ? Text(m.role) : null,
                    onTap: () async {
                      Navigator.of(context).pop();
                      await provider.switchFronter(m.id);
                    },
                  )),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SystemProvider>();

    if (!provider.isVaultConfigured) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'Set up your Obsidian vault folder in Settings to get started.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16),
          ),
        ),
      );
    }

    final history = provider.recentHistory.take(6).toList();

    return RefreshIndicator(
      onRefresh: provider.refresh,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          FronterCard(
            member: provider.currentMember,
            entry: provider.currentEntry,
            avatarFullPath: provider.avatarPath(provider.currentMember?.avatarFilename),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => _showSwitchSheet(context, provider),
            icon: const Icon(Icons.swap_horiz),
            label: const Text('Switch Fronter'),
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(48),
            ),
          ),
          const SizedBox(height: 24),
          const Text('Recent History', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (history.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Text('No switches logged yet.'),
            )
          else
            ...history.map((e) {
              final member = provider.memberById(e.memberId);
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: MemberAvatar(
                    member: member,
                    radius: 18,
                    avatarFullPath: provider.avatarPath(member?.avatarFilename),
                  ),
                  title: Text(member?.name ?? 'Unknown'),
                  subtitle: Text(
                    e.isActive
                        ? 'Since ${DateFormat('MMM d, h:mm a').format(e.start)}'
                        : '${DateFormat('MMM d, h:mm a').format(e.start)} '
                          '\u2192 ${DateFormat('h:mm a').format(e.end!)}',
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}
