import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/system_provider.dart';
import '../widgets/member_avatar.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SystemProvider>();

    if (!provider.isVaultConfigured) {
      return const Center(child: Text('Set up your vault folder in Settings first.'));
    }
    if (provider.entries.isEmpty || provider.members.isEmpty) {
      return const Center(child: Text('Log some switches to see stats here.'));
    }

    final counts = provider.switchCountsByMember;
    final averages = provider.averageDurationByMember;
    final membersWithData = provider.members.where((m) => counts.containsKey(m.id)).toList();
    final maxCount = counts.values.isEmpty ? 1 : counts.values.reduce((a, b) => a > b ? a : b);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Switch frequency', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        SizedBox(
          height: 220,
          child: BarChart(
            BarChartData(
              maxY: (maxCount + 1).toDouble(),
              barGroups: [
                for (int i = 0; i < membersWithData.length; i++)
                  BarChartGroupData(
                    x: i,
                    barRods: [
                      BarChartRodData(
                        toY: (counts[membersWithData[i].id] ?? 0).toDouble(),
                        color: membersWithData[i].color,
                        width: 22,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ],
                  ),
              ],
              titlesData: FlTitlesData(
                leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 28)),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      final i = value.toInt();
                      if (i < 0 || i >= membersWithData.length) return const SizedBox.shrink();
                      return Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(
                          membersWithData[i].name,
                          style: const TextStyle(fontSize: 10),
                          overflow: TextOverflow.ellipsis,
                        ),
                      );
                    },
                  ),
                ),
              ),
              gridData: const FlGridData(show: false),
              borderData: FlBorderData(show: false),
            ),
          ),
        ),
        const SizedBox(height: 28),
        const Text('Average time fronting', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...membersWithData.map((m) {
          final avg = averages[m.id] ?? Duration.zero;
          final h = avg.inHours;
          final min = avg.inMinutes % 60;
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: MemberAvatar(
                member: m,
                radius: 18,
                avatarFullPath: provider.avatarPath(m.avatarFilename),
              ),
              title: Text(m.name),
              subtitle: Text('${counts[m.id]} switches logged'),
              trailing: Text(
                h > 0 ? '${h}h ${min}m avg' : '${min}m avg',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          );
        }),
      ],
    );
  }
}
