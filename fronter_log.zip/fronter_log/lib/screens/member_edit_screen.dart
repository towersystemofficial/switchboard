import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../models/member.dart';
import '../providers/system_provider.dart';
import '../widgets/color_picker_dialog.dart';
import '../widgets/member_avatar.dart';

class MemberEditScreen extends StatefulWidget {
  final Member? member;
  const MemberEditScreen({super.key, required this.member});

  @override
  State<MemberEditScreen> createState() => _MemberEditScreenState();
}

class _MemberEditScreenState extends State<MemberEditScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _pronounsController;
  late TextEditingController _roleController;
  late TextEditingController _notesController;
  late String _colorHex;
  File? _pickedAvatar;

  bool get _isNew => widget.member == null;

  @override
  void initState() {
    super.initState();
    final m = widget.member;
    _nameController = TextEditingController(text: m?.name ?? '');
    _pronounsController = TextEditingController(text: m?.pronouns ?? '');
    _roleController = TextEditingController(text: m?.role ?? '');
    _notesController = TextEditingController(text: m?.notes ?? '');
    _colorHex = m?.colorHex ?? '#7C83FD';
  }

  @override
  void dispose() {
    _nameController.dispose();
    _pronounsController.dispose();
    _roleController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickAvatar() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choose from gallery'),
              onTap: () => Navigator.of(context).pop(ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('Take a photo'),
              onTap: () => Navigator.of(context).pop(ImageSource.camera),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;
    final picker = ImagePicker();
    final file = await picker.pickImage(source: source, maxWidth: 800, imageQuality: 85);
    if (file != null) {
      setState(() => _pickedAvatar = File(file.path));
    }
  }

  Future<void> _save(SystemProvider provider) async {
    if (!_formKey.currentState!.validate()) return;
    final id = widget.member?.id ?? provider.newMemberId();
    final member = Member(
      id: id,
      name: _nameController.text.trim(),
      pronouns: _pronounsController.text.trim(),
      role: _roleController.text.trim(),
      notes: _notesController.text,
      colorHex: _colorHex,
      avatarFilename: widget.member?.avatarFilename,
    );
    await provider.addOrUpdateMember(member, avatarFile: _pickedAvatar);
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _delete(SystemProvider provider) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete member?'),
        content: Text('This removes ${widget.member!.name}\'s profile file from your vault. '
            'Fronting history entries will remain but show as unknown.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await provider.deleteMember(widget.member!);
      if (mounted) Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.read<SystemProvider>();
    final color = Color(int.parse('FF${_colorHex.replaceFirst('#', '')}', radix: 16));
    final existingAvatarPath = provider.avatarPath(widget.member?.avatarFilename);

    return Scaffold(
      appBar: AppBar(
        title: Text(_isNew ? 'New Member' : 'Edit Member'),
        actions: [
          if (!_isNew)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () => _delete(provider),
            ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Center(
              child: GestureDetector(
                onTap: _pickAvatar,
                child: Stack(
                  children: [
                    _pickedAvatar != null
                        ? CircleAvatar(radius: 48, backgroundImage: FileImage(_pickedAvatar!))
                        : MemberAvatar(
                            member: widget.member,
                            radius: 48,
                            avatarFullPath: existingAvatarPath,
                          ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: CircleAvatar(
                        radius: 16,
                        backgroundColor: Theme.of(context).colorScheme.primary,
                        child: const Icon(Icons.edit, size: 16, color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Name', border: OutlineInputBorder()),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Name is required' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _pronounsController,
              decoration: const InputDecoration(labelText: 'Pronouns', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _roleController,
              decoration: const InputDecoration(labelText: 'Role', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Color'),
              trailing: CircleAvatar(backgroundColor: color, radius: 16),
              onTap: () async {
                final picked = await showColorPickerDialog(context, _colorHex);
                if (picked != null) setState(() => _colorHex = picked);
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _notesController,
              decoration: const InputDecoration(
                labelText: 'Notes',
                border: OutlineInputBorder(),
                alignLabelWithHint: true,
              ),
              maxLines: 6,
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: () => _save(provider),
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
              child: Text(_isNew ? 'Add Member' : 'Save Changes'),
            ),
          ],
        ),
      ),
    );
  }
}
