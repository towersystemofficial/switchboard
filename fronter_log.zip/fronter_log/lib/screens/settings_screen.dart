import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/system_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _portController;

  @override
  void initState() {
    super.initState();
    _portController = TextEditingController();
  }

  @override
  void dispose() {
    _portController.dispose();
    super.dispose();
  }

  Future<void> _pickVault(SystemProvider provider) async {
    final path = await FilePicker.platform.getDirectoryPath(
      dialogTitle: 'Select your Obsidian vault folder',
    );
    if (path != null) {
      await provider.setVaultPath(path);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Vault connected. A "FronterLog" folder was created inside it.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SystemProvider>();
    _portController.text = provider.apiPort.toString();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Obsidian Vault', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Card(
          child: ListTile(
            leading: const Icon(Icons.folder_open),
            title: Text(provider.vaultPath ?? 'No vault selected'),
            subtitle: const Text('Members, avatars and the fronting log are stored here'),
            trailing: TextButton(
              onPressed: () => _pickVault(provider),
              child: Text(provider.isVaultConfigured ? 'Change' : 'Choose'),
            ),
          ),
        ),
        const SizedBox(height: 24),
        const Text('Local API', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(
          'Exposes read-only endpoints on your local network so a script or LLM tool '
          'can query current fronter, history, members, and stats directly from this app.',
          style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
        ),
        const SizedBox(height: 8),
        Card(
          child: Column(
            children: [
              SwitchListTile(
                title: const Text('Enable local API server'),
                value: provider.apiEnabled,
                onChanged: provider.isVaultConfigured
                    ? (v) => provider.setApiEnabled(v)
                    : null,
              ),
              ListTile(
                title: const Text('Port'),
                trailing: SizedBox(
                  width: 100,
                  child: TextField(
                    controller: _portController,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.right,
                    decoration: const InputDecoration(border: OutlineInputBorder(), isDense: true),
                    onSubmitted: (v) {
                      final port = int.tryParse(v);
                      if (port != null && port > 1024 && port < 65536) {
                        provider.setApiPort(port);
                      }
                    },
                  ),
                ),
              ),
              if (provider.apiEnabled)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Try: http://<this-device-ip>:${provider.apiPort}/fronters/current',
                      style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const Text('About', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Fronter Log v0.1\n\n'
              'A personal, local-first system tracker. All data lives as plain Markdown '
              'and CSV files inside your own Obsidian vault -- nothing is sent anywhere.',
            ),
          ),
        ),
      ],
    );
  }
}
