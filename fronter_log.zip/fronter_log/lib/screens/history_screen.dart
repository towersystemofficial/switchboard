import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/front_entry.dart';
import '../providers/system_provider.dart';
import '../widgets/member_avatar.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  Future<void> _editEntry(BuildContext context, SystemProvider provider, FrontEntry entry) async {
    DateTime start = entry.start;
    DateTime? end = entry.end;
    final notesController = TextEditingController(text: entry.notes);

    Future<DateTime?> pickDateTime(DateTime initial) async {
      final date = await showDatePicker(
        context: context,
        initialDate: initial,
        firstDate: DateTime(2015),
        lastDate: DateTime.now().add(const Duration(days: 1)),
      );
      if (date == null) return null;
      if (!context.mounted) return null;
      final time = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(initial),
      );
      if (time == null) return null;
      return DateTime(date.year, date.month, date.day, time.hour, time.minute);
    }

    await showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Edit fronting entry'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Start'),
                      subtitle: Text(DateFormat('MMM d, y h:mm a').format(start)),
                      trailing: const Icon(Icons.edit),
                      onTap: () async {
                        final picked = await pickDateTime(start);
                        if (picked != null) setState(() => start = picked);
                      },
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('End'),
                      subtitle: Text(end != null ? DateFormat('MMM d, y h:mm a').format(end!) : 'Still fronting'),
                      trailing: const Icon(Icons.edit),
                      onTap: () async {
                        final picked = await pickDateTime(end ?? DateTime.now());
                        if (picked != null) setState(() => end = picked);
                      },
                    ),
                    if (end != null)
                      TextButton(
                        onPressed: () => setState(() => end = null),
                        child: const Text('Mark as still fronting'),
                      ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: notesController,
                      decoration: const InputDecoration(labelText: 'Notes'),
                      maxLines: 3,
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () async {
                    await provider.deleteEntry(entry);
                    if (context.mounted) Navigator.of(context).pop();
                  },
                  style: TextButton.styleFrom(foregroundColor: Colors.red),
                  child: const Text('Delete'),
                ),
                TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
                FilledButton(
                  onPressed: () async {
                    final index = provider.entries.indexOf(entry);
                    final updated = entry.copyWith(
                      start: start,
                      end: end,
                      clearEnd: end == null,
                      notes: notesController.text,
                    );
                    await provider.updateEntry(index, updated);
                    if (context.mounted) Navigator.of(context).pop();
                  },
                  child: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SystemProvider>();
    final history = provider.recentHistory;

    if (!provider.isVaultConfigured) {
      return const Center(child: Text('Set up your vault folder in Settings first.'));
    }

    if (history.isEmpty) {
      return const Center(child: Text('No fronting history yet.'));
    }

    return ListView.separated(
      padding: const EdgeInsets.all(12),
      itemCount: history.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final entry = history[i];
        final member = provider.memberById(entry.memberId);
        final h = entry.duration.inHours;
        final m = entry.duration.inMinutes % 60;
        return ListTile(
          leading: MemberAvatar(
            member: member,
            radius: 20,
            avatarFullPath: provider.avatarPath(member?.avatarFilename),
          ),
          title: Text(member?.name ?? 'Unknown'),
          subtitle: Text(
            entry.isActive
                ? 'Since ${DateFormat('MMM d, h:mm a').format(entry.start)} \u00b7 ongoing'
                : '${DateFormat('MMM d, h:mm a').format(entry.start)} \u2192 '
                  '${DateFormat('h:mm a').format(entry.end!)} \u00b7 ${h}h ${m}m',
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _editEntry(context, provider, entry),
        );
      },
    );
  }
}
