import 'dart:io';
import 'package:flutter/foundation.dart';

import '../models/member.dart';
import '../models/front_entry.dart';
import '../services/vault_service.dart';
import '../services/notification_service.dart';
import '../services/api_server_service.dart';

class SystemProvider extends ChangeNotifier {
  final VaultService vaultService = VaultService();
  final NotificationService notificationService = NotificationService();
  late final ApiServerService apiServerService;

  List<Member> members = [];
  List<FrontEntry> entries = [];
  bool loading = true;
  bool apiEnabled = false;
  int apiPort = 8787;

  SystemProvider() {
    apiServerService = ApiServerService(
      getMembers: () => members,
      getEntries: () => entries,
    );
  }

  bool get isVaultConfigured => vaultService.isConfigured;
  String? get vaultPath => vaultService.vaultPath;

  FrontEntry? get currentEntry {
    if (entries.isEmpty) return null;
    final last = entries.last;
    return last.isActive ? last : null;
  }

  Member? get currentMember {
    final entry = currentEntry;
    if (entry == null) return null;
    final matches = members.where((m) => m.id == entry.memberId);
    return matches.isEmpty ? null : matches.first;
  }

  List<FrontEntry> get recentHistory {
    final sorted = [...entries]..sort((a, b) => b.start.compareTo(a.start));
    return sorted;
  }

  Member? memberById(String id) {
    final matches = members.where((m) => m.id == id);
    return matches.isEmpty ? null : matches.first;
  }

  Future<void> init() async {
    loading = true;
    notifyListeners();
    await vaultService.load();
    await notificationService.init();
    apiEnabled = await vaultService.getApiEnabled();
    apiPort = await vaultService.getApiPort();
    if (vaultService.isConfigured) {
      await _loadAll();
    }
    if (apiEnabled) {
      await apiServerService.start(apiPort);
    }
    loading = false;
    notifyListeners();
  }

  Future<void> setVaultPath(String path) async {
    await vaultService.setVaultPath(path);
    await _loadAll();
    notifyListeners();
  }

  Future<void> _loadAll() async {
    members = await vaultService.loadMembers();
    entries = await vaultService.loadFrontingLog();
    await _updateNotification();
  }

  Future<void> refresh() async {
    await _loadAll();
    notifyListeners();
  }

  // ---------------- Members ----------------

  Future<void> addOrUpdateMember(Member member, {File? avatarFile}) async {
    if (avatarFile != null) {
      final filename = await vaultService.saveAvatar(member.id, avatarFile);
      member.avatarFilename = filename;
    }
    await vaultService.saveMember(member);
    await _loadAll();
    notifyListeners();
  }

  Future<void> deleteMember(Member member) async {
    await vaultService.deleteMember(member);
    await _loadAll();
    notifyListeners();
  }

  String newMemberId() => vaultService.newId();

  String? avatarPath(String? filename) => vaultService.avatarPath(filename);

  // ---------------- Fronting log ----------------

  Future<void> switchFronter(String memberId, {String notes = ''}) async {
    final now = DateTime.now();
    if (entries.isNotEmpty && entries.last.isActive) {
      entries.last = entries.last.copyWith(end: now);
    }
    entries.add(FrontEntry(memberId: memberId, start: now, notes: notes));
    await vaultService.writeFrontingLog(entries);
    await _updateNotification();
    notifyListeners();
  }

  Future<void> endCurrentFront() async {
    if (entries.isEmpty || !entries.last.isActive) return;
    entries.last = entries.last.copyWith(end: DateTime.now());
    await vaultService.writeFrontingLog(entries);
    await _updateNotification();
    notifyListeners();
  }

  Future<void> updateEntry(int index, FrontEntry updated) async {
    entries[index] = updated;
    entries.sort((a, b) => a.start.compareTo(b.start));
    await vaultService.writeFrontingLog(entries);
    await _updateNotification();
    notifyListeners();
  }

  Future<void> deleteEntry(FrontEntry entry) async {
    entries.remove(entry);
    await vaultService.writeFrontingLog(entries);
    await _updateNotification();
    notifyListeners();
  }

  Future<void> _updateNotification() async {
    final entry = currentEntry;
    final member = entry != null ? memberById(entry.memberId) : null;
    await notificationService.showCurrentFronter(member, entry?.start);
  }

  // ---------------- Stats ----------------

  Map<String, int> get switchCountsByMember {
    final counts = <String, int>{};
    for (final e in entries) {
      counts[e.memberId] = (counts[e.memberId] ?? 0) + 1;
    }
    return counts;
  }

  Map<String, Duration> get averageDurationByMember {
    final totals = <String, Duration>{};
    final counts = switchCountsByMember;
    for (final e in entries) {
      totals[e.memberId] = (totals[e.memberId] ?? Duration.zero) + e.duration;
    }
    return {
      for (final id in totals.keys)
        id: Duration(seconds: totals[id]!.inSeconds ~/ (counts[id] ?? 1))
    };
  }

  // ---------------- API server ----------------

  Future<void> setApiEnabled(bool enabled) async {
    apiEnabled = enabled;
    await vaultService.setApiEnabled(enabled);
    if (enabled) {
      await apiServerService.start(apiPort);
    } else {
      await apiServerService.stop();
    }
    notifyListeners();
  }

  Future<void> setApiPort(int port) async {
    apiPort = port;
    await vaultService.setApiPort(port);
    if (apiEnabled) {
      await apiServerService.start(port);
    }
    notifyListeners();
  }
}
