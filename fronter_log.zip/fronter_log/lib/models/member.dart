import 'package:flutter/material.dart';

/// A single system member / alter profile.
class Member {
  final String id;
  String name;
  String pronouns;
  String role;
  String notes;
  String colorHex;
  String? avatarFilename;

  Member({
    required this.id,
    required this.name,
    this.pronouns = '',
    this.role = '',
    this.notes = '',
    this.colorHex = '#7C83FD',
    this.avatarFilename,
  });

  Color get color {
    var hex = colorHex.replaceFirst('#', '');
    if (hex.length == 6) hex = 'FF$hex';
    return Color(int.parse(hex, radix: 16));
  }

  String get initials {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return '?';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return (parts.first.substring(0, 1) + parts.last.substring(0, 1)).toUpperCase();
  }

  Member copyWith({
    String? name,
    String? pronouns,
    String? role,
    String? notes,
    String? colorHex,
    String? avatarFilename,
  }) {
    return Member(
      id: id,
      name: name ?? this.name,
      pronouns: pronouns ?? this.pronouns,
      role: role ?? this.role,
      notes: notes ?? this.notes,
      colorHex: colorHex ?? this.colorHex,
      avatarFilename: avatarFilename ?? this.avatarFilename,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'pronouns': pronouns,
        'role': role,
        'notes': notes,
        'color': colorHex,
        'avatar': avatarFilename,
      };
}
