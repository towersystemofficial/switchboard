import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/system_provider.dart';
import 'screens/home_shell.dart';

void main() {
  runApp(const FronterLogApp());
}

class FronterLogApp extends StatelessWidget {
  const FronterLogApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => SystemProvider()..init(),
      child: MaterialApp(
        title: 'Fronter Log',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorSchemeSeed: const Color(0xFF7C83FD),
          useMaterial3: true,
          brightness: Brightness.light,
        ),
        darkTheme: ThemeData(
          colorSchemeSeed: const Color(0xFF7C83FD),
          useMaterial3: true,
          brightness: Brightness.dark,
        ),
        themeMode: ThemeMode.system,
        home: const HomeShell(),
      ),
    );
  }
}
