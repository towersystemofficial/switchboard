import 'package:flutter/material.dart';

const List<String> presetColors = [
  '#7C83FD', '#F76E96', '#FFB562', '#5FD068',
  '#4EA5D9', '#B983FF', '#FF6B6B', '#38B6A8',
  '#F7C548', '#7286D3', '#E27396', '#8DC63F',
];

Future<String?> showColorPickerDialog(BuildContext context, String currentHex) {
  return showDialog<String>(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: const Text('Choose a color'),
        content: SizedBox(
          width: 280,
          child: GridView.count(
            crossAxisCount: 4,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            shrinkWrap: true,
            children: presetColors.map((hex) {
              final color = Color(int.parse('FF${hex.replaceFirst('#', '')}', radix: 16));
              final selected = hex.toUpperCase() == currentHex.toUpperCase();
              return GestureDetector(
                onTap: () => Navigator.of(context).pop(hex),
                child: Container(
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: selected ? Border.all(color: Colors.black87, width: 3) : null,
                  ),
                  child: selected ? const Icon(Icons.check, color: Colors.white) : null,
                ),
              );
            }).toList(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
        ],
      );
    },
  );
}
