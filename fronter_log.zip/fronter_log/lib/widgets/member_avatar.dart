import 'dart:io';
import 'package:flutter/material.dart';
import '../models/member.dart';

class MemberAvatar extends StatelessWidget {
  final Member? member;
  final double radius;
  final String? avatarFullPath;

  const MemberAvatar({
    super.key,
    required this.member,
    this.radius = 24,
    this.avatarFullPath,
  });

  @override
  Widget build(BuildContext context) {
    if (member == null) {
      return CircleAvatar(
        radius: radius,
        backgroundColor: Colors.grey.shade300,
        child: Icon(Icons.person_outline, size: radius, color: Colors.grey.shade600),
      );
    }

    final path = avatarFullPath;
    if (path != null && File(path).existsSync()) {
      return CircleAvatar(
        radius: radius,
        backgroundImage: FileImage(File(path)),
      );
    }

    return CircleAvatar(
      radius: radius,
      backgroundColor: member!.color,
      child: Text(
        member!.initials,
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: radius * 0.7,
        ),
      ),
    );
  }
}
