import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/member.dart';
import '../models/front_entry.dart';
import 'member_avatar.dart';

class FronterCard extends StatefulWidget {
  final Member? member;
  final FrontEntry? entry;
  final String? avatarFullPath;

  const FronterCard({
    super.key,
    required this.member,
    required this.entry,
    this.avatarFullPath,
  });

  @override
  State<FronterCard> createState() => _FronterCardState();
}

class _FronterCardState extends State<FronterCard> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes % 60;
    if (h > 0) return '${h}h ${m}m';
    return '${m}m';
  }

  @override
  Widget build(BuildContext context) {
    final member = widget.member;
    final entry = widget.entry;
    final color = member?.color ?? Colors.grey.shade400;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.85), color.withOpacity(0.55)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(color: color.withOpacity(0.3), blurRadius: 16, offset: const Offset(0, 8)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'CURRENTLY FRONTING',
            style: TextStyle(
              color: Colors.white.withOpacity(0.85),
              fontWeight: FontWeight.w600,
              letterSpacing: 1.2,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              MemberAvatar(member: member, radius: 32, avatarFullPath: widget.avatarFullPath),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      member?.name ?? 'No one set',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (member?.role.isNotEmpty == true)
                      Text(
                        member!.role,
                        style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 14),
                      ),
                  ],
                ),
              ),
            ],
          ),
          if (entry != null) ...[
            const SizedBox(height: 20),
            Row(
              children: [
                Icon(Icons.schedule, color: Colors.white.withOpacity(0.9), size: 18),
                const SizedBox(width: 6),
                Text(
                  'Since ${DateFormat('h:mm a').format(entry.start)} '
                  '(${_formatDuration(entry.duration)})',
                  style: TextStyle(color: Colors.white.withOpacity(0.95), fontSize: 14),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
